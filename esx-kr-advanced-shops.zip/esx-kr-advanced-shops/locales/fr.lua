Locales['fr'] = {
  ['press_to_open'] = 'appuyez sur ~INPUT_CONTEXT~ pour ouvrir la boutique.',
	['press_to_rob'] = 'appuyez sur ~INPUT_CONTEXT~ pour ~r~braquer ~w~cette boutique.',
	['press_to_open_center'] = 'appuyez sur ~INPUT_CONTEXT~ pour ouvrir la centrale.',
	['name_shop'] = 'comment voulez-vous nommer votre boutique?',
	['buy_shop'] = 'acheter une boutique ',
	['robbery_cancel'] = '~r~le braquage est annulé (vous êtes trop éloigné)',
	['set_price'] = 'définir le prix de l\'article.',
	['how_much'] = 'définir la quantité de de l\'article',
}
