----------------------------
--(Made By Qalle)--
----------------------------

resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'ESX Marker'

version '0.0.1'

client_scripts {
  'client/main.lua'
}

server_scripts {
  'server/main.lua'
}
