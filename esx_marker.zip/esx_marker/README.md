# esx_marker

[REQUIREMENTS]
  
* ESX
  
[USAGE]

* Type /tpm to teleport to your waypoint.

[INSTALLATION]

1) Drag the resource in to your [resources] folder

2) Add this in your server.cfg (under esx)
``start esx_marker``
