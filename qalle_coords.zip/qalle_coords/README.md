# qalle_coords

[REQUIREMENTS]
  
* NONE, Standalone
  
[USAGE]

* Type /coords to toggle between showing and not showing the coords.
* This makes it easier for you to decide where your markers and such will be.

[INSTALLATION]

1) Drag the resource in to your [resources] folder

2) Add this in your server.cfg (doesn't matter where)
``start qalle_coords``
